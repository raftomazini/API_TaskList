import json

# Variaveis publicas
taskFile = "taskFile.json"
tasks = []

# Funcao para carregar as taferas do arquivo
def load_tasks():
    try:
        with open(taskFile, "r") as file:
            return json.load(file)
        file.close()
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        return []
    except:
        return []

# Funcao para gravar as tarefas no arquivo
def save_tasks():
    try:
        file = open(taskFile, "w+")
        json.dump(tasks, file, indent=4)        
        file.close()
    except Exception as e:
        return []

# Função para obter todas as tarefas
def get_all_tasks():
    return tasks

# Função para obter as tarefas ativas
def get_active_tasks():
    return [task for task in tasks if task['status'] == 'Em Andamento']

# Função para obter as tarefas concluidas
def get_inactive_tasks():
    return [task for task in tasks if task['status'] == "Concluido"]

# Função para obter a tarefa pelo ID
def get_task_by_id(task_id: int):
    for task in tasks:
        if task['id'] == task_id:
            return task
    raise None

# Função para adicionar uma nova tarefa
def add_task(description: str):
    if tasks:
        new_id = max(task['id'] for task in tasks) + 1
    else:
        new_id = 0

    new_task = {
        'id': new_id,
        'description': description,
        'status': 'Em Andamento'
    }
    tasks.append(new_task)
    save_tasks()
    return tasks

# Função para excluir uma tarefa
def del_task_by_id(value: int):
    try:
        task_id = int(value)
    except ValueError:
        print("O ID informado deve ser um numero inteiro")
        return
    
    global tasks
    
    new_taskList = [task for task in tasks if task['id'] != task_id]

    if len(new_taskList) < len(tasks):
        tasks = new_taskList
        save_tasks()
        return True
    else:
        raise False

# Função para alterar uma tarefa    
def change_task(id: int, description: str, status: str):
    task_id = id
    new_description = description
    new_status = status
    
    # Busca o índice (posição) da tarefa na lista, usando o ID
    try:
        # Encontra o índice do primeiro item onde o ID corresponde
        idx = next(i for i, task in enumerate(tasks) if task["id"] == task_id)
    except StopIteration:
        # Se o 'next' não encontrar nada, lança 404
        raise False
    
    try:
        if new_description:
            tasks[idx]['description'] = new_description

        old_status = tasks[idx]["status"]
        if new_status in ('Em Andamento', 'Concluido'):
            if new_status != old_status:
                tasks[idx]["status"] = new_status
                
        try:
            save_tasks()
            return tasks[idx]
        except:
            raise False
    except:
        raise False
    
# Carrega a lista de taferas
tasks = load_tasks()